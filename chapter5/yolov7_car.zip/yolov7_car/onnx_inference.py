import cv2
import time
import argparse
import requests
import random
import numpy as np
import onnxruntime as ort
import os
from PIL import Image
from pathlib import Path
from collections import OrderedDict,namedtuple


def letterbox(im, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleup=True, stride=32):
    # Resize and pad image while meeting stride-multiple constraints
    shape = im.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better val mAP)
        r = min(r, 1.0)

    # Compute padding
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding

    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
    return im, r, (dw, dh)

def load_model(weights, cuda):
    providers = ['CUDAExecutionProvider', 'CPUExecutionProvider'] if cuda else ['CPUExecutionProvider']
    session = ort.InferenceSession(weights, providers=providers)
    inname = [i.name for i in session.get_inputs()]
    outname = [i.name for i in session.get_outputs()]

    return session, inname, outname

def detect(session, inname, outname, img, class_names):
    image = img.copy()
    image, ratio, dwdh = letterbox(image, auto=False)
    image = image.transpose((2, 0, 1))
    image = np.expand_dims(image, 0)
    image = np.ascontiguousarray(image)
    im = image.astype(np.float32)
    im /= 255

    start = time.perf_counter()
    inp = {inname[0]:im}
    outputs = session.run(outname, inp)[0]
    print(f'Cost {time.perf_counter()-start} s')

    ori_images = [img.copy()]
    colors = {name:[random.randint(0, 255) for _ in range(3)] for i,name in enumerate(class_names)}

    for i,(batch_id,x0,y0,x1,y1,cls_id,score) in enumerate(outputs):
        image = ori_images[int(batch_id)]
        box = np.array([x0,y0,x1,y1])
        box -= np.array(dwdh*2)
        box /= ratio
        box = box.round().astype(np.int32).tolist()
        cls_id = int(cls_id)
        score = round(float(score),3)
        name = class_names[cls_id]
        color = colors[name]
        name += ' '+str(score)
        lx, ly = box[:2]
        rx, ry = box[2:]
        cv2.rectangle(image, (lx, ly), (rx, ry),color,2)
        cv2.putText(image,name,(box[0], box[1] - 2),cv2.FONT_HERSHEY_SIMPLEX,0.75,[225, 255, 255],thickness=2)  

    return image


def run(weights, class_names, source_path, save_file):
    cuda = True
    session, inname, outname = load_model(weights, cuda)

    if not os.path.exists(save_file):
        os.makedirs(save_file)

    if source_path.endswith('.jpg') or source_path.endswith('.png'):
        source_flag = 'image'

    elif source_path.endswith('.mp4') or source_path.endswith('.avi'):
        source_flag = 'video'

    else:
        raise("source_path  error !!!")

    if source_flag == 'image':
        img = cv2.imread(source_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        image = detect(session, inname, outname, img, class_names)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        save_path = os.path.join(save_file, 'onnx_output.jpg')
        cv2.imwrite(save_path, image)

    elif source_flag == 'video':
        cap = cv2.VideoCapture(source_path)
        fps = cap.get(cv2.CAP_PROP_FPS)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        save_path = os.path.join(save_file, 'onnx_output.mp4')
        cap_writer = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))

        while (cap.isOpened()):
            ret, frame = cap.read()

            if ret == True:
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image = detect(session, inname, outname, img, class_names)
                img = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

                cap_writer.write(image)

            else:
                break

        cap.release()
        cap_writer.release()
        # cv2.destroyAllWindows()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str, default='best.onnx', help='weights path')
    parser.add_argument('--source-path', type=str, default='test.jpg', help='input file')
    parser.add_argument('--save-file', type=str, default='save_onnx', help='save results path')
    args = parser.parse_args()

    weights = args.weights
    source_path = args.source_path
    save_file = args.save_file

    # class_names = ['Ambulance', 'Bus', 'Car', 'Motorcycle', 'Truck']
    class_names = ['Car']
    run(weights, class_names, source_path, save_file)