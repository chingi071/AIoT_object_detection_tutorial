import cv2
import torch
import os
import argparse
import random
import time
import numpy as np
import tensorrt as trt
from PIL import Image
from pathlib import Path
from collections import OrderedDict,namedtuple


def infer_trt_engine(weights, device):
    # Infer TensorRT Engine
    Binding = namedtuple('Binding', ('name', 'dtype', 'shape', 'data', 'ptr'))
    logger = trt.Logger(trt.Logger.INFO)
    trt.init_libnvinfer_plugins(logger, namespace="")
    with open(weights, 'rb') as f, trt.Runtime(logger) as runtime:
        model = runtime.deserialize_cuda_engine(f.read())
    bindings = OrderedDict()
    for index in range(model.num_bindings):
        name = model.get_binding_name(index)
        dtype = trt.nptype(model.get_binding_dtype(index))
        shape = tuple(model.get_binding_shape(index))
        data = torch.from_numpy(np.empty(shape, dtype=np.dtype(dtype))).to(device)
        bindings[name] = Binding(name, dtype, shape, data, int(data.data_ptr()))
    binding_addrs = OrderedDict((n, d.ptr) for n, d in bindings.items())
    context = model.create_execution_context()

    return bindings, binding_addrs, context

def letterbox(im, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleup=True, stride=32):
    # Resize and pad image while meeting stride-multiple constraints
    shape = im.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better val mAP)
        r = min(r, 1.0)

    # Compute padding
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding

    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
    return im, r, (dw, dh)

def postprocess(boxes,r,dwdh):
    dwdh = torch.tensor(dwdh*2).to(boxes.device)
    boxes -= dwdh
    boxes /= r
    return boxes

def detect(bindings, binding_addrs, context, device, img, class_names):
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    image = img.copy()
    image, ratio, dwdh = letterbox(image, auto=False)
    image = image.transpose((2, 0, 1))
    image = np.expand_dims(image, 0)
    image = np.ascontiguousarray(image)
    im = image.astype(np.float32)
    im = torch.from_numpy(im).to(device)
    im/=255

    # warmup for 10 times
    for _ in range(10):
        tmp = torch.randn(1,3,640,640).to(device)
        binding_addrs['images'] = int(tmp.data_ptr())
        context.execute_v2(list(binding_addrs.values()))

    start = time.perf_counter()
    binding_addrs['images'] = int(im.data_ptr())
    context.execute_v2(list(binding_addrs.values()))
    print(f'Cost {time.perf_counter()-start} s')

    nums = bindings['num_dets'].data
    boxes = bindings['det_boxes'].data
    scores = bindings['det_scores'].data
    classes = bindings['det_classes'].data
    nums.shape,boxes.shape,scores.shape,classes.shape

    boxes = boxes[0,:nums[0][0]]
    scores = scores[0,:nums[0][0]]
    classes = classes[0,:nums[0][0]]

    colors = {name:[random.randint(0, 255) for _ in range(3)] for i,name in enumerate(class_names)}
    for box,score,cl in zip(boxes,scores,classes):
        box = postprocess(box,ratio,dwdh).round().int()
        name = class_names[cl]
        color = colors[name]
        name += ' ' + str(round(float(score),3))
        lx, ly = box[:2].tolist()
        rx, ry = box[2:].tolist()
        cv2.rectangle(img, (lx, ly), (rx, ry),color,2)
        cv2.putText(img, name,(int(box[0]), int(box[1]) - 2),cv2.FONT_HERSHEY_SIMPLEX,0.75,color,thickness=2)

    return img

def run(weights, class_names, source_path, save_file, device_id):
    device = torch.device(device_id)
    bindings, binding_addrs, context = infer_trt_engine(weights, device)

    if not os.path.exists(save_file):
        os.makedirs(save_file)

    if source_path.endswith('.jpg') or source_path.endswith('.png'):
        source_flag = 'image'

    elif source_path.endswith('.mp4') or source_path.endswith('.avi'):
        source_flag = 'video'

    else:
        raise("source_path  error !!!")

    if source_flag == 'image':
        img = cv2.imread(source_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        image = detect(bindings, binding_addrs, context, device, img, class_names)

        save_path = os.path.join(save_file, 'trt_output.jpg')
        cv2.imwrite(save_path, image)

    elif source_flag == 'video':
        cap = cv2.VideoCapture(source_path)
        fps = cap.get(cv2.CAP_PROP_FPS)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        save_path = os.path.join(save_file, 'trt_output.mp4')
        cap_writer = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))

        while (cap.isOpened()):
            ret, frame = cap.read()

            if ret == True:
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image = detect(bindings, binding_addrs, context, device, img, class_names)
                img = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

                cap_writer.write(image)

            else:
                break

        cap.release()
        cap_writer.release()
        # cv2.destroyAllWindows()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str, default='best.trt', help='weights path')
    parser.add_argument('--source-path', type=str, default='test.jpg', help='input file')
    parser.add_argument('--save-file', type=str, default='save_trt', help='save results path')
    args = parser.parse_args()

    weights = args.weights
    source_path = args.source_path
    save_file = args.save_file

    class_names = ['Car']
    device_id = 'cuda:0'
    run(weights, class_names, source_path, save_file, device_id)

